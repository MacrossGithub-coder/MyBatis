create
    definer = root@localhost procedure queryCountByGradeWithProcedure(IN gName varchar(20), OUT scount int)
BEGIN
	SELECT COUNT(*) INTO scount FROM student WHERE graname = gName;

END;

